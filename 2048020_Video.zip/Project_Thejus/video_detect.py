"""Object tracking in a local video."""
from google.cloud import videointelligence
import io
import os


def videodetect(path):
    os.environ['GOOGLE_APPLICATION_CREDENTIALS']="C:/Users/adish/OneDrive/Desktop/qwiklabs-gcp-03-f64767610d0f-11b083a22aaf (1).json"
    out=[]
    video_client = videointelligence.VideoIntelligenceServiceClient()
    features = [videointelligence.Feature.OBJECT_TRACKING]

    with io.open(path, "rb") as file:
        input_content = file.read()
    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content}
    )
    result = operation.result(timeout=500)
    # The first result is retrieved because a single video was processed.
    object_annotations = result.annotation_results[0].object_annotations

    # Get only the first annotation for demo purposes.
    object_annotation = object_annotations[0]
    out.append(object_annotation.entity.description)
    return out