from flask import *
import os
from video_detect import *

app=Flask(__name__)
app.config['SECRET_KEY']='emotion'
app.config['UPLOAD_FOLDER']="E:\CHRIST_MDS2\MDS_2\CA\Project_Thejus\Videos"

@app.route('/',methods=['GET','POST'])
def homepage():
    if request.method=='POST':
        file=request.files['file']
        file_loc=os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_loc)
        out=videodetect(file_loc)
        return render_template('result.html',data=out)
    return render_template('obj_detect.html')